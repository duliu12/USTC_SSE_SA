export default {
    ws: {},
    homePage:null,
    clientPage:null,
    setWs: function(newWs) {
        this.ws = newWs
    },
    setHomePage: function(homePage) {
        this.homePage = homePage
    },
    setClientPage: function(clientPage) {
        this.clientPage = clientPage 
    }
}