package com.ustc.qingpark.webmanage.web;

public class WebIntecepter {
}
