package com.ustc.qingpark.webmanage.service.Impl;

import com.ustc.qingpark.webmanage.global.Global;
import com.ustc.qingpark.webmanage.service.NotifyService;
import com.ustc.qingpark.webmanage.util.Message;
import com.ustc.qingpark.webmanage.web.websocket.WebSocketServer;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service("notifyService")
public class NotifyServiceImpl implements NotifyService {
    @Override
    public void messageTest(String message, int clientId) throws IOException {
        WebSocketServer.send(message,clientId);
    }

    @Override
    public void handleMessage(Message message, int clientId)throws IOException {
         WebSocketServer.send(message.toString(),clientId);
    }
}
